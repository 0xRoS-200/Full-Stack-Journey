const registerUser = async (req, res) => {
  res.send("registered");
};

export { registerUser };
